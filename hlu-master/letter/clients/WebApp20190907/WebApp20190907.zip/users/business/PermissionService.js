(function () {
    'use strict';

    angular.module('Hrm.User').service('PermissionService', PermissionService);

    PermissionService.$inject = [
        '$http',
        '$q',
        '$filter',
        'settings',
        'Utilities'
    ];

    function PermissionService($http, $q, $filter, settings, utils) {
        var self = this;
        var baseUrl = settings.api.baseUrl + settings.api.apiPrefix;
    }
})();