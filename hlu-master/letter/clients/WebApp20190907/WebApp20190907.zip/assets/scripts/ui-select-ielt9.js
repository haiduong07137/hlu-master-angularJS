/**
 * Created by bizic on 1/10/2016.
 */
(function () {
    document.createElement('ui-select');
    document.createElement('ui-select-match');
    document.createElement('ui-select-choices');
})();