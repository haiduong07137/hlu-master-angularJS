/**
 * Created by bizic on 30/8/2016.
 */
(function () {
    'use strict';

})();